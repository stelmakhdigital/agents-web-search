# Changelog — @agents-web-search/core

Формат — Keep a Changelog; даты — по факту коммитов (ветка `master`).

## [1.5.1] — 2026-11-20

### Fixed

- SSRF-блок-лист: добавлены 100.64.0.0/10 (CGNAT/Tailscale),
  198.18.0.0/15 (benchmark), 224.0.0.0/4 (multicast) и 240.0.0.0/4
  (reserved) — проходили наружу, хотя документация обещала покрытие.
- Ключ кэша поиска учитывает maxResults: запрос на 20 результатов больше
  не получает cache-hit от запроса на 5.
- recordSearch: fallback-SELECT для id при upsert (lastInsertRowid = 0),
  как в recordPage — searchId больше не теряется.

### Изменено (документация)

- ssrf.trustEnvProxy честно помечен no-op (consumer'а в коде нет).
- Формулировки о защите: DNS-резолв проверяется до запроса, но
  классический DNS-rebinding не закрывается; SSRF-проверка браузера
  выполняется до навигации и по финальному URL, промежуточные
  redirect-ходы не проверяются.

## [1.5.0] — 2026-11-21

### Added

- Антибот-гигиена запуска браузера (по умолчанию, без конфига):
  - `--disable-blink-features=AutomationControlled` — снимает флаг
    `navigator.webdriver`;
  - user-agent контекста выводится из реальной версии сборки
    (`HeadlessChrome/159…` или голое `159.0.8154.6` → `Chrome/159.0.0.0`,
    платформенный токен по ОС хоста); переопределяется `browser.userAgent`;
  - headless теперь запускает полный Chromium в new-headless
    (`headlessMode: 'chrome'` по умолчанию) — отпечаток заметно честнее
    классического headless-shell; если скачан только shell, провайдер сам
    откатывается на shell. `browser.headlessMode: 'shell'` возвращает
    прежнее поведение.
- Новые поля конфига `browser`: `headlessMode`, `userAgent`, `launchArgs`.

### Why

Голое headless-shell с UA `HeadlessChrome` резалось антибот-проверками
сайтов (нестиковая проверка: Авито отдаёт «Доступ ограничен», с этими
флагами и UA выдача открывается headless-запуском из коробки).

## [1.4.0] — 2026-11-20

### Added

- `installChromium()` — скачивание бинарника Chromium через локальный
  playwright CLI (`playwright install chromium`), одним child-process
  вызовом: пишет только в кэш браузера пользователя, не требует прав,
  идемпотентно. Системные библиотеки сознательно НЕ ставятся (root-слой) —
  для них hint с командой под дистрибутив. Хосты зовут это в фоне по флагу
  `browser.autoDownload` (pi-адаптер).
- Hint readiness про недостающие системные библиотеки стал дистрибутивно-
  точным: семья пакетов определяется по `/etc/os-release` (ID/ID_LIKE) и к
  универсальному `npx playwright install --with-deps chromium` добавляется
  прямая команда: apt (`libnspr4 libnss3 libasound2t64`), dnf, pacman или
  apk (`nspr nss alsa-lib`). Для нераспознанных дистрибутивов — только
  универсальная форма, выдуманных пакетов нет. Швы: `ReadinessDeps.distro`,
  экспорт `detectDistroFamily`.

### Tests

- `test/browser-install.test.ts` — seam-вызовы CLI + реальный `runCapturing`
  на тривиальных node-процессах (без сети).

## [1.3.1] — 2026-11-18

### Fixed

- `browserReadiness()` больше не вводит в заблуждение на голых Linux-хостах:
  бинарник Chromium может лежать на диске, но не запускаться без системных
  библиотек (libnspr4/libnss3/libasound). Readiness теперь дополнительно
  разбирает `ldd` бинарника (Linux-only, без запуска браузера) и при
  недостающих библиотеках отдаёт hint со списком библиотек и командами
  `npx playwright install --with-deps chromium` / apt. Проверочный шов
  `browserReadiness({ platform, missingLibs })` для тестов; `lddMissingLibs`
  экспортирован.

### Tests

- `test/live-browser.local.test.ts` — живой браузерный e2e (open → snapshot
  → click → close на реальном Chromium), гейт `WEB_SEARCH_LIVE=1`, чистый
  skip когда браузер не запускается; вне CI.

## [1.3.0] — 2026-11-07

### Added

- `CONCURRENT_TOOLS` — единый состав инструментов, безопасных для
  параллельного запуска (web_platform_search, get_search_content,
  web_history, web_search_stats, web_cache_clear); адаптеры больше не
  держат свои копии, чтобы политика параллелизма не расходилась между
  хостами.
- `JsonSchemaNode` — публичный тип формы `ToolSpec.parameters` для
  проекций адаптеров (type-only импорт, без рантайм-зависимости).

## [1.2.1] — 2026-11-07

### Fixed

- markdown: inline-элементы (ссылки, code, img), висящие прямо в блоке
  (div/body), выпадали из вывода — ветка заполняла буфер и не печатала его;
  теперь общий inline-walker с разделителем `<br>` (в блоке — перенос, в
  собранном тексте — пробел).
- markdown: `pickMainRoot` читал текст поддерева через глобальный
  `$.root().find(el)` на каждый матч (O(матчи × документ)) — теперь
  `$(el).text()`; 30 удалений тегов сведены в один проход.

### Changed

- `web_search` с несколькими `queries` выполняет их параллельно
  (всеSettled; ошибка первого запроса по-прежнему фейлит вызов), мердж —
  в порядке запросов, семантика dedupe сохранена.
- web_history: фильтр `query` опускается в SQL (`LIKE` с экранированием
  `%`/`_`/`\`) — раньше при фильтре возвращалось меньше строк, чем
  совпадает глубже в истории; `recentSearches`/`recentPages` получили
  опциональный фильтр.
- store: кэш подготовленных выражений (node:sqlite компилирует SQL на
  каждый `prepare()` — было 24 точки на горячих путях чтения).
- browser: процесс Chromium закрывается при ошибке после launch
  (невалидный storageState и т.п.); устаревшие `data-aws-ref` снимаются в
  начале каждого снапшота (клик по ref больше не попадает в чужой элемент
  после повторного снапшота).
- fetch: три копии «recordPage + memory.set + pageId» сведены в
  `persistPage()`.

## [1.2.0] — 2026-11-07

### Added

- In-memory page cache (LRU, 50 entries, TTL = `fetch.cacheTtlMs`) перед
  SQLite-store: повторные `web_fetch`/`get_search_content` в сессии идут без
  обращения к store; `web_cache_clear` (pages/all) чистит и его. Конфиг —
  `fetch.memoryCacheMaxEntries` (0 — выключить).

### Fixed

- Убраны недостижимые `return` в `fetchFresh`/`revalidate` (мёртвый код).

## [1.1.1] — 2026-11-07

Ядро поставляется с декларациями типов; публичная проверка готовности
браузера. Исправляет CI адаптеров: в GH-окружении sibling-путь `paths` не
резолвился, а тарболл был без типов (implicit-any каскад с 2026-09-29).

### Добавлено

- `browserReadiness()` (и тип `BrowserReadiness`) в публичном API: докладует,
  что playwright импортируем и бинарник Chromium скачан, с actionable-подсказкой;
  ничего не запускает и не качает — для `session_start` хостов.
- `lib/index.d.ts`: сборка генерирует декларации (`tsc -p tsconfig.build.json`,
  `rewriteRelativeImportExtensions`); `types` + `exports.types` в package.json.
- Тесты: `browserReadiness` на реальном окружении.

### Изменено

- CI: actions/checkout@v5, actions/setup-node@v5 (снимает deprecation Node 20).
- README (RU/EN): секция Browser-модуля — pi-адаптер включает браузер по
  умолчанию, `browserReadiness()` как встроенная проверка.

## [1.1.0] — 2026-11-07

SearXNG — первый движок дефолтной цепочки; быстрый отказ; чистка boilerplate
HTTP-движков; диагностика движков; удалён мёртвый конфиг.

> Примечание: версия пакета поднята с 1.0.0; `.vendor`-тарболл адаптеров
> теперь `agents-web-search-core-1.1.0.tgz`.

### Изменено

- `DEFAULT_ENGINES` = `['searxng', 'ddg', 'bing']` (было `['ddg', 'bing']`):
  пустой конфиг сначала пробует локальный инстанс SearXNG, затем
  безключевые ddg/bing. Явные конфиги с `search.engines` работают как есть.
- Быстрый отказ недоступного инстанса: ECONNREFUSED завершается сразу
  (без ретраев); молчащий хост срезается connect-гардом (~3 s, опция
  `connectTimeoutMs` у SearXNGEngine), таймер снимается после заголовков.
- `src/search/engines/`: общий `HttpSearchClient` (rate-limit, fetch/
  classify/capped-read, маппинг статусов `serpStatusErrors`/`apiStatusErrors`)
  и хелперы `dedupeSources`/`isBlockedDomain` — дубли убраны из ddg, bing,
  searxng, tavily, jina, exa, brave, ollama. Публичный API и формат
  `SearchSource` не менялись.

### Добавлено

- Экспорт `SEARXNG_DEFAULT_ENDPOINT` и типа `EngineDiagnostics` из
  `src/index.ts` (адаптерам для health-check и диагностики).
- `MultiSearchProvider.diagnostics()` — состояние каждого движка
  (availability, in-chain, cooldown, оставшиеся мс, число подряд неудач);
  выводится инструментом `web_search_stats` (текст + `details.engines`).
- Тесты: fast-fail на закрытом порту, cooldown-пропуск после падения,
  connect-guard (тихий хост / живой эндпоинт), дедупликация; fuse-режим
  (RRF-слияние, частичный отказ, полный отказ, диагностика); живой
  интеграционный тест локального инстанса — opt-in `WEB_SEARCH_LIVE=1`.

### Удалено

- Мёртвый конфиг `extended.contentCache` (резерв 6.5, никогда не имел
  эффекта): удалён из `CoreConfig`, `ResolvedCoreConfig` и README.
  Пользовательские конфиги с этим ключом больше не валидируются ядром
  (лишние поля JSON игнорируются, ошибка не бросается).

## [1.0.0] — 2026-09-21

Первый стабильный релиз: полный функциональный скоуп (фазы 3–7), security-
ревью, E2E-проверка в реальных хостах (DSH + Pi).

### Добавлено (с 0.1.0)

- **Расширенный fetch (фаза 5)**:
  - PDF — локальное извлечение (`unpdf`), `fetch.pdf` (20 MB / 50 стр.);
  - YouTube-документы — oEmbed + description + таймcoded-транскрипт
    (без ffmpeg), `fetch.video`;
  - GitHub — repo/tree/blob через shallow-клон кэш (200 MB / 500 записей),
    PR/issue — keyless REST API (404 → `WEB_NOT_AVAILABLE`, 403/429 →
    `WEB_QUOTA`), `fetch.github`;
  - curator UI — локальный HTTP-сервер 127.0.0.1 + 128-бит Bearer-токен:
    ревизия поисков/страниц, LLM-саммари через `HostAdapter.llm`
    (fail-closed без LLM), discard; инструмент `web_curator`
    (`extended.curator.enabled`);
  - `get_search_content` — чтение полного закэшированного контента по id
    записи (`findText`/`offset`/`limit`); `SearchResult.searchId` /
    `FetchResult.pageId` печатаются в выводах `web_search`/`web_fetch`.
- **Q9-линт (6.1)**: `lint:no-host-imports` — запрет host-импортов в core
  (автоматически в CI).
- **Security (6.3)**: SSRF-гард на каждый редирект-хоп во всех сетевых
  путях (включая video-субзапросы — ранее `redirect: 'follow'`);
  curator runtime-предупреждение о loopback/TLS при `curator.remote: true`.
- **Несовместимости (6.4)**: документированы и проверены (double-install
  DSH → actionable `WEB_DUPLICATE_PROVIDER`; Pi tool-name conflict →
  fail-fast; core double-install — безопасен: нет мутабельного глобального
  состояния).
- **Лимиты (6.5)**: полная инвентаризация + таблица дефолтов в README;
  `extended.contentCache` задокументирован как reserved/no-op v0.1.
- **README (7.1)**: RU + EN — установка в DSH/Pi, «как написать свой
  адаптер» (HostAdapter), конфиг-референс, privacy-модель, browser-модуль.

### Изменено

- `videoSubFetch` — перенесён на `fetchPublic` (SSRF-повторная проверка
  каждого редирект-хопа; `SsrfBlockedError` → `WEB_SSRF_BLOCKED`).
- `web_curator` (start) — при `curator.remote: true` в ответе заметка:
  «remote access deferred — loopback only, no TLS».

### Тесты и качество

- 298 тестов (база 195 + extended 86 + lint 6 + security 10 + limits 1);
  coverage 68.35/60.44/71.07/71.77 (пороги 55/50/60/58 + per-dir).
- CI: node 22, `npm ci` → typecheck → lint:no-host-imports →
  test:coverage.
- E2E-дым (6.2): DSH-профиль (`dsh plugin add`, `--dump-config`, boot Web
  UI), smoke 6/6 (реальные сети + headless Chromium), provider-native 3/3
  (mock Messages API), Pi + mock LLM (реальный tool-call).

## [0.1.0] — 2026-09-20

Начальная версия (фаза 3): ядро без host-зависимостей —
`createWebStack(host)`; 14 поисковых движков (ddg/bing keyless, searxng/
ollama локальные, exa/jina/tavily/brave API, openai/xai/anthropic/
deepseek/gemini/perplexity provider-native) + multi-роутер (fallback /
fuse+RRF); cached fetch с SSRF-защитой (literal + post-DNS, per-hop);
platform-поиск (github, reddit, youtube, bilibili, v2ex, rss + custom);
web store (SQLite: история + кэш, eviction); инструменты
`web_search`/`web_fetch`/`web_platform_search`/`web_history`/
`web_search_stats`/`web_cache_clear`; browser-модуль (Playwright,
optional, off по умолчанию, fail-closed approvals).
