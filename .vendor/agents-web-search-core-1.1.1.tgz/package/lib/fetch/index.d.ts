/**
 * Core fetch layer: the SQLite-cached anonymous public HTTP(S) fetcher.
 * The ported `CachedHttpFetchProvider` owns transport + cache semantics; this
 * module provides the limits builder from the resolved core config.
 *
 * The page cache lives in the shared web store (the same `web_pages` table the
 * search enrichment writes), so a page fetched by `web_fetch` is reused by
 * `web_search` enrichment and vice versa.
 * @module @agents-web-search/core/fetch
 */
import type { ResolvedCoreConfig } from '../config.ts';
import type { WebStore } from '../store/index.ts';
import type { CachedFetchLimits } from './provider.ts';
export { CACHED_FETCH_PROVIDER_ID, CachedHttpFetchProvider } from './provider.ts';
export type { CachedFetchLimits } from './provider.ts';
export { checkSsrf, SsrfBlockedError, fetchPublic, SSRF_MAX_REDIRECTS } from './ssrf.ts';
export type { SsrfCheckResult } from './ssrf.ts';
export { validateFetchUrl, isSameOrigin, parseCharset, decoderForCharset, classifyContentType, type FetchableKind } from './policy.ts';
export { normalizeUrl as normalizeFetchUrl } from './url.ts';
/**
 * Build the resolved fetch limits from the core config.
 * `userAgent` is host-injected (product UA with host identity; ADR-005 §5).
 */
export declare function buildFetchLimits(config: ResolvedCoreConfig, store: WebStore, userAgent: string): CachedFetchLimits;
